<?php
namespace app\forms;

use std, gui, framework, app;


class ATA2 extends AbstractForm
{

}
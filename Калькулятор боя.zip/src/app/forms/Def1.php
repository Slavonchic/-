<?php
namespace app\forms;

use std, gui, framework, app;


class Def1 extends AbstractForm
{

}
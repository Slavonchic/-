<?php
namespace app\forms;

use std, gui, framework, app;


class PereBoDbl extends AbstractForm
{

    /**
     * @event button.mouseEnter 
     */
    function doButtonMouseEnter(UXMouseEvent $e = null)
    {    
        
    }

}

<?php
namespace app\forms;

use std, gui, framework, app;


class ATA1 extends AbstractForm
{

}
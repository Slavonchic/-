<?php
namespace app\forms;

use std, gui, framework, app;


class Def2 extends AbstractForm
{

}
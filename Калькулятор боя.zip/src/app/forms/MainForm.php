<?php
namespace app\forms;

use std, gui, framework, app;


class MainForm extends AbstractForm
{

    /**
     * @event button.mouseDown 
     */
    function doButtonMouseDown(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event buttonAlt.mouseDown-Left 
     */
    function doButtonAltMouseDownLeft(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event image.globalKeyDown-F1 
     */
    function doImageGlobalKeyDownF1(UXKeyEvent $e = null)
    {    
        
    }

    /**
     * @event image.globalKeyDown-F2 
     */
    function doImageGlobalKeyDownF2(UXKeyEvent $e = null)
    {    
        
    }

    /**
     * @event button3.click-Left 
     */
    function doButton3ClickLeft(UXMouseEvent $e = null)
    {    
        
    }











}

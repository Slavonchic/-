<?php
namespace app\forms;

use std, gui, framework, app;


class Hactrouku extends AbstractForm
{


    /**
     * @event checkbox3.mouseEnter 
     */
    function doCheckbox3MouseEnter(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event checkbox4.mouseEnter 
     */
    function doCheckbox4MouseEnter(UXMouseEvent $e = null)
    {    
        
    }




}
